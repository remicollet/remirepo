/* vim: set expandtab tabstop=4 shiftwidth=4 softtabstop=4: */
/* 
 * php_shout.c
 *
 * Copyright (C) 2005-2007 Brandon Holbrook <brandon at theholbrooks.org>
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Library General Public
 *  License as published by the Free Software Foundation; either
 *  version 2 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Library General Public License for more details.
 *
 *  You should have received a copy of the GNU Library General Public
 *  License along with this library; if not, write to the Free
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * $Id: shout.c 108 2007-01-06 05:01:27Z holbrookbw $
 */

#ifdef HAVE_CONFIG_H
# include "config.h"
#endif

#include "php.h"
#include "php_globals.h"
#include "ext/standard/info.h"

#ifdef ZEND_ENGINE_2
# include "zend_exceptions.h"
#else
# error This phpShout requires at least PHP 5
#endif

#if HAVE_SIGNAL_H
# include <signal.h>
#endif
#if HAVE_SYS_TYPES_H
# include <sys/types.h>
#endif
#include <netdb.h>
#include <netinet/in.h>
#if HAVE_ARPA_INET_H
# include <arpa/inet.h>
#endif

#ifndef __LIBSHOUT_SHOUT_H__
#include <shout.h>
#endif

// True globals
static int le_link, le_plink;

#define SAFE_STRING(s) ((s)?(s):"")

// We wouldn't have to do this if libshout would just EXPORT
//	 their version ID in a #define
#define SHOUT_VERSION_ID(buf) { \
	int _major=0, _minor=0, _patch=0; \
	shout_version(&_major, &_minor, &_patch); \
	buf = 10000 * _major + 100 * _minor + _patch; }
#define SHOUT_VERSION_STRING(buf) { \
	int _major=0, _minor=0, _patch=0; \
	sprintf(buf, "%s", shout_version(&_major, &_minor, &_patch)); }

#include "php_ini.h"
#include "php_shout.h"

typedef struct _php_shout_conn {
	shout_t *conn;
	zend_bool inUse;
	char *passwd;
	int passwdLen;
} php_shout_conn;

/* {{{ shout_functions[]
 *
 * Every user visible function must have an entry in shout_functions[].
 */
zend_function_entry shout_functions[] = {
		PHP_FE(shout_get_all_persistent, NULL)

		PHP_FE(shout_create, NULL)
		PHP_FE(shout_pcreate, NULL)
		PHP_FE(shout_connect, NULL)
		PHP_FALIAS(shout_open, shout_connect, NULL)	// Alias for shout_connect
		PHP_FE(shout_close,   NULL)
		PHP_FE(shout_send,    NULL)
		PHP_FE(shout_sync,    NULL)

		PHP_FE(shout_get_connected, NULL)
		PHP_FE(shout_get_errno,     NULL)
		PHP_FE(shout_get_error,     NULL)

		PHP_FE(shout_get_host,        NULL)
		PHP_FE(shout_get_port,        NULL)
		PHP_FE(shout_get_password,    NULL)
		PHP_FE(shout_get_mount,       NULL)
		PHP_FE(shout_get_name,        NULL)
		PHP_FE(shout_get_url,         NULL)
		PHP_FE(shout_get_genre,       NULL)
		PHP_FE(shout_get_user,        NULL)
		PHP_FE(shout_get_agent,       NULL)
		PHP_FE(shout_get_description, NULL)
		PHP_FE(shout_get_public,      NULL)
		PHP_FE(shout_get_format,      NULL)
		PHP_FE(shout_get_protocol,    NULL)
		PHP_FE(shout_get_nonblocking, NULL)

		PHP_FE(shout_get_audio_info, NULL)

		PHP_FE(shout_set_host,        NULL)
		PHP_FE(shout_set_port,        NULL)
		PHP_FE(shout_set_password,    NULL)
		PHP_FE(shout_set_mount,       NULL)
		PHP_FE(shout_set_name,        NULL)
		PHP_FE(shout_set_url,         NULL)
		PHP_FE(shout_set_genre,       NULL)
		PHP_FE(shout_set_user,        NULL)
		PHP_FE(shout_set_agent,       NULL)
		PHP_FE(shout_set_description, NULL)
		PHP_FE(shout_set_public,      NULL)
		PHP_FE(shout_set_format,      NULL)
		PHP_FE(shout_set_protocol,    NULL)
		PHP_FE(shout_set_nonblocking, NULL)
		
		PHP_FE(shout_set_metadata,   NULL)
		PHP_FE(shout_set_audio_info, NULL)
		{NULL, NULL, NULL}
};
/* }}} */

/* {{{ shout_module_entry
 */
zend_module_entry shout_module_entry = {
		STANDARD_MODULE_HEADER,
		"shout",
		shout_functions,
		PHP_MINIT(shout),
		PHP_MSHUTDOWN(shout),
		PHP_RINIT(shout),
		PHP_RSHUTDOWN(shout),
		PHP_MINFO(shout),
		PHP_SHOUT_VERSION,
		STANDARD_MODULE_PROPERTIES
};
/* }}} */

ZEND_DECLARE_MODULE_GLOBALS(shout);

#ifdef COMPILE_DL_SHOUT
ZEND_GET_MODULE(shout)
#endif

//#define CHECK_LINK(link) {if (link == -1) { php_error_docref(NULL TSRMLS_CC, E_WARNING, "A link to the server could not be established"); RETURN_FALSE; } }

/*
static void php_shout_get_hash(shout_t *shout, char *hash, int *length) {
	*length = sizeof("shout___") + strlen(SAFE_STRING(shout_get_host(shout))) + 5 + strlen(SAFE_STRING(shout_get_mount(shout))) - 1;
	hash = (char *) emalloc(*length+1);
	sprintf(hash, "shout_%s_%5i_%s", SAFE_STRING(shout_get_host(shout)), shout_get_port(shout), SAFE_STRING(shout_get_mount(shout)));

	return;
}
*/

static void php_shout_set_default_link(int id TSRMLS_DC) {
	if (MySG(default_link) != -1) {
		zend_list_delete(MySG(default_link));
	}
	MySG(default_link) = id;
	zend_list_addref(id);
}

static void _close_shout_link(zend_rsrc_list_entry *rsrc TSRMLS_DC) {
	php_shout_conn *link = (php_shout_conn *)rsrc->ptr;
	void (*handler) (int);

	handler = signal(SIGPIPE, SIG_IGN);
	shout_close(link->conn);
	signal(SIGPIPE, handler);

	shout_free(link->conn);
	MySG(num_links)--;
}

static void _close_shout_plink(zend_rsrc_list_entry *rsrc TSRMLS_DC) {
	php_shout_conn *link = (php_shout_conn *)rsrc->ptr;
	void (*handler) (int);

	handler = signal(SIGPIPE, SIG_IGN);
	shout_close(link->conn);
	signal(SIGPIPE, handler);

	shout_free(link->conn);
	MySG(num_persistent)--;
	MySG(num_links)--;
}

static PHP_INI_MH(OnShoutPort) {
	if (new_value != NULL) {
		MySG(default_port) = atoi(new_value);
	} else { /* use default port */
		MySG(default_port) = -1;
	}

	return SUCCESS;
}

/* {{{ PHP_INI_BEGIN
*/
PHP_INI_BEGIN()
	STD_PHP_INI_BOOLEAN("shout.allow_persistent",	"1",	PHP_INI_SYSTEM,		OnUpdateBool,		allow_persistent,	zend_shout_globals,		shout_globals)
	STD_PHP_INI_ENTRY_EX("shout.max_persistent",     "-1",	PHP_INI_SYSTEM, OnUpdateLong,		max_persistent,			zend_shout_globals,		shout_globals,	display_link_numbers)
	STD_PHP_INI_ENTRY_EX("shout.max_links",     "-1",	PHP_INI_SYSTEM, OnUpdateLong,		max_links,			zend_shout_globals,		shout_globals,	display_link_numbers)
	STD_PHP_INI_ENTRY("shout.default_host",     NULL,	PHP_INI_ALL,		OnUpdateString,		default_host,		zend_shout_globals,		shout_globals)
	STD_PHP_INI_ENTRY("shout.default_mount",    NULL,	PHP_INI_ALL,		OnUpdateString,		default_mount,		zend_shout_globals,		shout_globals)
	STD_PHP_INI_ENTRY("shout.default_user",     NULL,	PHP_INI_ALL,		OnUpdateString,		default_user,	zend_shout_globals,		shout_globals)
	STD_PHP_INI_ENTRY("shout.default_password", NULL,	PHP_INI_ALL,		OnUpdateString,		default_password,	zend_shout_globals,		shout_globals)
	PHP_INI_ENTRY("shout.default_port",         NULL,	PHP_INI_ALL,		OnShoutPort)
	STD_PHP_INI_ENTRY("shout.default_protocol", "0", PHP_INI_ALL,		OnUpdateLong,		default_protocol, 	zend_shout_globals,		shout_globals)
	STD_PHP_INI_ENTRY("shout.default_format",   "0", PHP_INI_ALL,		OnUpdateLong,		default_format, 	zend_shout_globals,		shout_globals)
	STD_PHP_INI_ENTRY("shout.connect_timeout",  "60",	PHP_INI_ALL,		OnUpdateLong,		connect_timeout, 	zend_shout_globals,		shout_globals)
PHP_INI_END()
/* }}} */

/* {{{ php_shout_init_globals
 */
static void php_shout_init_globals(zend_shout_globals *shout_globals) {
	shout_globals->num_persistent = 0;
	shout_globals->default_host = NULL;
	shout_globals->default_mount = NULL;
	shout_globals->default_user = NULL;
	shout_globals->default_password = NULL;
	shout_globals->default_port = 0;
	shout_globals->default_protocol = 0;
	shout_globals->default_format = 0;
	shout_globals->connect_errno = 0;
	shout_globals->connect_error = NULL;
	shout_globals->connect_timeout = 0;
}
/* }}} */

/* {{{ PHP_MINIT_FUNCTION
 */
PHP_MINIT_FUNCTION(shout) {
	ZEND_INIT_MODULE_GLOBALS(shout, php_shout_init_globals, NULL);

	REGISTER_INI_ENTRIES();
	le_link = zend_register_list_destructors_ex(_close_shout_link, NULL, "Shout Link", module_number);
	le_plink = zend_register_list_destructors_ex(NULL, _close_shout_plink, "Shout Link Persistent", module_number);
	Z_TYPE(shout_module_entry) = type;

	REGISTER_LONG_CONSTANT("SHOUTERR_SUCCESS",     SHOUTERR_SUCCESS, CONST_CS | CONST_PERSISTENT); // 0
	REGISTER_LONG_CONSTANT("SHOUTERR_INSANE",      SHOUTERR_INSANE, CONST_CS | CONST_PERSISTENT); // -1
	REGISTER_LONG_CONSTANT("SHOUTERR_NOCONNECT",   SHOUTERR_NOCONNECT, CONST_CS | CONST_PERSISTENT); // -2
	REGISTER_LONG_CONSTANT("SHOUTERR_NOLOGIN",     SHOUTERR_NOLOGIN, CONST_CS | CONST_PERSISTENT); // -3
	REGISTER_LONG_CONSTANT("SHOUTERR_SOCKET",      SHOUTERR_SOCKET, CONST_CS | CONST_PERSISTENT); // -4
	REGISTER_LONG_CONSTANT("SHOUTERR_MALLOC",      SHOUTERR_MALLOC, CONST_CS | CONST_PERSISTENT); // -5
	REGISTER_LONG_CONSTANT("SHOUTERR_METADATA",    SHOUTERR_METADATA, CONST_CS | CONST_PERSISTENT); // -6
	REGISTER_LONG_CONSTANT("SHOUTERR_CONNECTED",   SHOUTERR_CONNECTED, CONST_CS | CONST_PERSISTENT); // -7
	REGISTER_LONG_CONSTANT("SHOUTERR_UNCONNECTED", SHOUTERR_UNCONNECTED, CONST_CS | CONST_PERSISTENT); // -8
	REGISTER_LONG_CONSTANT("SHOUTERR_UNSUPPORTED", SHOUTERR_UNSUPPORTED, CONST_CS | CONST_PERSISTENT); // -9
	REGISTER_LONG_CONSTANT("SHOUTERR_BUSY",        SHOUTERR_BUSY, CONST_CS | CONST_PERSISTENT); // -10

	REGISTER_LONG_CONSTANT("SHOUT_FORMAT_OGG",    SHOUT_FORMAT_OGG, CONST_CS | CONST_PERSISTENT); // 0
	REGISTER_LONG_CONSTANT("SHOUT_FORMAT_MP3",    SHOUT_FORMAT_MP3, CONST_CS | CONST_PERSISTENT); // 1
	REGISTER_LONG_CONSTANT("SHOUT_FORMAT_VORBIS", SHOUT_FORMAT_VORBIS, CONST_CS | CONST_PERSISTENT); // 0

	REGISTER_LONG_CONSTANT("SHOUT_PROTOCOL_HTTP",       SHOUT_PROTOCOL_HTTP, CONST_CS | CONST_PERSISTENT); // 0
	REGISTER_LONG_CONSTANT("SHOUT_PROTOCOL_XAUDIOCAST", SHOUT_PROTOCOL_XAUDIOCAST, CONST_CS | CONST_PERSISTENT); // 1
	REGISTER_LONG_CONSTANT("SHOUT_PROTOCOL_ICY",        SHOUT_PROTOCOL_ICY, CONST_CS | CONST_PERSISTENT); // 2

	REGISTER_STRING_CONSTANT("SHOUT_AI_BITRATE",    SHOUT_AI_BITRATE, CONST_CS | CONST_PERSISTENT); // "bitrate"
	REGISTER_STRING_CONSTANT("SHOUT_AI_SAMPLERATE", SHOUT_AI_SAMPLERATE, CONST_CS | CONST_PERSISTENT); // "samplerate"
	REGISTER_STRING_CONSTANT("SHOUT_AI_CHANNELS",   SHOUT_AI_CHANNELS, CONST_CS | CONST_PERSISTENT); // "channels"
	REGISTER_STRING_CONSTANT("SHOUT_AI_QUALITY",    SHOUT_AI_QUALITY, CONST_CS | CONST_PERSISTENT); // "quality"

	REGISTER_STRING_CONSTANT("SHOUT_VERSION",    PHP_SHOUT_VERSION, CONST_CS | CONST_PERSISTENT);

	shout_init();
	return SUCCESS;
}
/* }}} */

/* {{{ PHP_MSHUTDOWN_FUNCTION
 */
PHP_MSHUTDOWN_FUNCTION(shout) {
	shout_shutdown();
	UNREGISTER_INI_ENTRIES();
	return SUCCESS;
}
/* }}} */

/* {{{ PHP_RINIT_FUNCTION
 */
PHP_RINIT_FUNCTION(shout) {
	MySG(default_link)  = -1;
	MySG(num_links) = MySG(num_persistent);
	/* Reset connect error/errno on every request */
	MySG(connect_error) = NULL;
	MySG(connect_errno) = 0;
	return SUCCESS;
}
/* }}} */

/* {{{ PHP_RSHUTDOWN_FUNCTION
 */
PHP_RSHUTDOWN_FUNCTION(shout) {
	if (MySG(connect_error)) {
		efree(MySG(connect_error));
	}
	return SUCCESS;
}
/* }}} */

/* {{{ PHP_MINFO_FUNCTION
 */
PHP_MINFO_FUNCTION(shout) {
	char buf[32];
	
	php_info_print_table_start();
	php_info_print_table_header(2, "Shout Support", "enabled");
	php_info_print_table_row(2, "Version", PHP_SHOUT_VERSION);
	SHOUT_VERSION_STRING(buf);
	php_info_print_table_row(2, "libshout version", buf);
	sprintf(buf, "%ld", MySG(num_persistent));
	php_info_print_table_row(2, "Active Persistent Links", buf);
	sprintf(buf, "%ld", MySG(num_links));
	php_info_print_table_row(2, "Active Links", buf);
	php_info_print_table_end();

#ifdef SHOUT_DEBUG
	php_info_print_table_start();
	php_info_print_table_header(1, "<span style='font-weight: 900; font-size: 12px;'>*** DEBUG OUTPUT HAS BEEN ENABLED ***</span>");
	php_info_print_table_end();
#endif

	DISPLAY_INI_ENTRIES();
}
/* }}} */

/* {{{ php_shout_create
 */
#define SHOUT_CREATE_CLEANUP()	\
	if (free_host) {						\
		efree(host);							\
	}														\
	if (free_host_port_mount) {	\
		efree(host_port_mount);		\
	}

#define SHOUT_CREATE_RETURN_FALSE()		\
	SHOUT_CREATE_CLEANUP();				\
	RETURN_FALSE;
	
static void php_shout_create(INTERNAL_FUNCTION_PARAMETERS, int persistent) {
	char *mount=NULL, *user=NULL, *password=NULL, *host_port_mount=NULL, *tmp=NULL, *host=NULL;
	char *hashed_details=NULL;
	int hashed_details_length, port = SHOUT_PORT;
	int format = 0, protocol = 0;
	php_shout_conn *shout=NULL;
//	void (*handler) (int);
	zval **z_host=NULL, **z_user=NULL, **z_password=NULL, **z_format=NULL, **z_protocol=NULL;
	zend_bool free_host=0, free_host_port_mount=0;
	long connect_timeout;

	connect_timeout = MySG(connect_timeout);

	if (MySG(default_port) < 0) {
#if !defined(PHP_WIN32) && !defined(NETWARE)
	struct servent *serv_ptr;
	char *env;
		
	MySG(default_port) = SHOUT_PORT;

	if ((serv_ptr = getservbyname("shout", "tcp"))) {
		MySG(default_port) = (uint) ntohs((ushort) serv_ptr->s_port);
	} else if ((serv_ptr = getservbyname("icecast", "tcp"))) {
		MySG(default_port) = (uint) ntohs((ushort) serv_ptr->s_port);
	}
	if ((env = getenv("SHOUT_TCP_PORT"))) {
		MySG(default_port) = (uint) atoi(env);
	}
#else
		MySG(default_port) = SHOUT_PORT;
#endif
	}

	host_port_mount = MySG(default_host);
	port = MySG(default_port);
	mount = MySG(default_mount);
	user = MySG(default_user);
	password = MySG(default_password);
	format = MySG(default_format);
	protocol = MySG(default_protocol);
	switch(ZEND_NUM_ARGS()) {
		case 1: {					
				if (zend_get_parameters_ex(1, &z_host)==FAILURE) {
					SHOUT_CREATE_RETURN_FALSE();
				}
			}
			break;
		case 2: {
				if (zend_get_parameters_ex(2, &z_host, &z_user) == FAILURE) {
					SHOUT_CREATE_RETURN_FALSE();
				}
				convert_to_string_ex(z_user);
				user = Z_STRVAL_PP(z_user);
			}
			break;
		case 3: {
				if (zend_get_parameters_ex(3, &z_host, &z_user, &z_password) == FAILURE) {
					SHOUT_CREATE_RETURN_FALSE();
				}
				convert_to_string_ex(z_user);
				convert_to_string_ex(z_password);
				user = Z_STRVAL_PP(z_user);
				password = Z_STRVAL_PP(z_password);
			}
			break;
		case 4: {
				if (zend_get_parameters_ex(4, &z_host, &z_user, &z_password, &z_format) == FAILURE) {
					SHOUT_CREATE_RETURN_FALSE();
				}
				convert_to_string_ex(z_user);
				convert_to_string_ex(z_password);
				convert_to_long_ex(z_format);
				user = Z_STRVAL_PP(z_user);
				password = Z_STRVAL_PP(z_password);
				format = Z_LVAL_PP(z_format);
			}
			break;
		case 5: {
				if (zend_get_parameters_ex(5, &z_host, &z_user, &z_password, &z_format, &z_protocol) == FAILURE) {
					SHOUT_CREATE_RETURN_FALSE();
				}
				convert_to_string_ex(z_user);
				convert_to_string_ex(z_password);
				convert_to_long_ex(z_format);
				convert_to_long_ex(z_protocol);
				user = Z_STRVAL_PP(z_user);
				password = Z_STRVAL_PP(z_password);
				format = Z_LVAL_PP(z_format);
				protocol = Z_LVAL_PP(z_protocol);
			}
			break;
		default:
			WRONG_PARAM_COUNT;
			break;
	}

	if (z_host) {
		SEPARATE_ZVAL(z_host); // We may modify z_host if it contains a port, separate
		convert_to_string_ex(z_host);
		host_port_mount = Z_STRVAL_PP(z_host);
		if (z_user) {
			convert_to_string_ex(z_user);
			user = Z_STRVAL_PP(z_user);
			if (z_password) {
				convert_to_string_ex(z_password);
				password = Z_STRVAL_PP(z_password);
				if (z_format) {
					convert_to_long_ex(z_format);
					format = Z_LVAL_PP(z_format);
					if (z_protocol) {
						convert_to_long_ex(z_protocol);
						protocol = Z_LVAL_PP(z_protocol);
					}
				}
			}
		}
	}
#ifdef SHOUT_DEBUG
	php_printf("Parsing host_port_mount='%s'\n", host_port_mount);
#endif
	if (host_port_mount && (tmp = strchr(host_port_mount, '/'))) {
#ifdef SHOUT_DEBUG
		php_printf("SLASH FOUND! tmp='%s'\n", tmp);
#endif
		mount = tmp;
		if (host_port_mount[0] == '/') {
			host_port_mount = MySG(default_host);
		} else {
			host_port_mount = estrndup(host_port_mount, tmp-host_port_mount);
			free_host_port_mount = 1;
		}
	} else {
		mount = MySG(default_mount);
	}
#ifdef SHOUT_DEBUG
	php_printf("Parsed mount='%s'\n", mount);
	php_printf("host_port_mount='%s'\n", host_port_mount);
#endif
	if (host_port_mount && (tmp=strchr(host_port_mount, ':'))) {
#ifdef SHOUT_DEBUG
		php_printf("COLON FOUND! tmp='%s'\n", tmp);
#endif
		port = atoi(tmp+1);
		if (host_port_mount[0] == ':') {
			host = MySG(default_host);
		} else {
			host = estrndup(host_port_mount, tmp-host_port_mount);
#ifdef SHOUT_DEBUG
	php_printf("just set host='%s'\n", host);
#endif
			free_host = 1;
		}
	} else {
		host = host_port_mount;
		port = MySG(default_port);
	}
	if (host_port_mount[0] == '\0') {
		host = MySG(default_host);
	}
#ifdef SHOUT_DEBUG
	php_printf("Parsed host='%s'\n", host);
	php_printf("Parsed port='%05i'\n", port);
#endif

	hashed_details_length = sizeof("shout___") + strlen(SAFE_STRING(host)) + 5 + strlen(SAFE_STRING(mount));
	hashed_details = (char *) emalloc(hashed_details_length+1);
	sprintf(hashed_details, "shout_%s_%05i_%s", SAFE_STRING(host), port, SAFE_STRING(mount));
#ifdef SHOUT_DEBUG
	php_printf("Calculated HASH='%s'\n", hashed_details);
#endif

	if (!MySG(allow_persistent)) {
		persistent=0;
	}
	if (persistent) {
#ifdef SHOUT_DEBUG
		php_printf("Creating PERSISTENT Object\n");
#endif
		zend_rsrc_list_entry *le;

#ifdef SHOUT_DEBUG
		php_printf("Searching for Object in Zend's global Hash Table...");
#endif
		/* try to find if we already have this link in our persistent list */
		if (zend_hash_find(&EG(persistent_list), hashed_details, hashed_details_length, (void **) &le)==FAILURE) {  /* we don't */
#ifdef SHOUT_DEBUG
			php_printf("NOT FOUND\n");
#endif
			zend_rsrc_list_entry new_le;

			if (MySG(max_links) != -1 && MySG(num_links) >= MySG(max_links)) {
				php_error_docref(NULL TSRMLS_CC, E_WARNING, "Too many open links (%ld)", MySG(num_links));
				efree(hashed_details);
				SHOUT_CREATE_RETURN_FALSE();
			}
			if (MySG(max_persistent) != -1 && MySG(num_persistent) >= MySG(max_persistent)) {
				php_error_docref(NULL TSRMLS_CC, E_WARNING, "Too many open persistent links (%ld)", MySG(num_persistent));
				efree(hashed_details);
				SHOUT_CREATE_RETURN_FALSE();
			}
			/* create the link */
			shout = (php_shout_conn *) malloc(sizeof(php_shout_conn));
			shout->conn = shout_new();
			shout->inUse = 0;
			if (shout_set_host(shout->conn, host) != SHOUTERR_SUCCESS) {
				php_error_docref(NULL TSRMLS_CC, E_WARNING, "Error setting hostname to '%s': %s\n", host, shout_get_error(shout->conn));
			}
			if (shout_set_port(shout->conn, port) != SHOUTERR_SUCCESS) {
				php_error_docref(NULL TSRMLS_CC, E_WARNING, "Error setting port to '%i': %s\n", port, shout_get_error(shout->conn));
			}
			if (shout_set_mount(shout->conn, mount) != SHOUTERR_SUCCESS) {
				php_error_docref(NULL TSRMLS_CC, E_WARNING, "Error setting mount to '%s': %s\n", mount, shout_get_error(shout->conn));
			}
			if (shout_set_user(shout->conn, user) != SHOUTERR_SUCCESS) {
				php_error_docref(NULL TSRMLS_CC, E_WARNING, "Error setting user to '%s': %s\n", user, shout_get_error(shout->conn));
			}
			if (shout_set_password(shout->conn, password) != SHOUTERR_SUCCESS) {
				php_error_docref(NULL TSRMLS_CC, E_WARNING, "Error setting password to '%s': %s\n", password, shout_get_error(shout->conn));
			}
			if (shout_set_format(shout->conn, format) != SHOUTERR_SUCCESS) {
				php_error_docref(NULL TSRMLS_CC, E_WARNING, "Error setting format to '%i': %s\n", format, shout_get_error(shout->conn));
			}
			if (shout_set_protocol(shout->conn, protocol) != SHOUTERR_SUCCESS) {
				php_error_docref(NULL TSRMLS_CC, E_WARNING, "Error setting protocol to '%i': %s\n", protocol, shout_get_error(shout->conn));
			}

			/* hash it up */
			Z_TYPE(new_le) = le_plink;
			new_le.ptr = shout;
#ifdef SHOUT_DEBUG
			php_printf("Inserting into Zend's global Hash Table...");
#endif
			if (zend_hash_update(&EG(persistent_list), hashed_details, hashed_details_length, (void *) &new_le, sizeof(zend_rsrc_list_entry), NULL)==FAILURE) {
				shout_free(shout->conn);
				free(shout);
				efree(hashed_details);
#ifdef SHOUT_DEBUG
				php_printf("FAILED!\n");
#endif
				SHOUT_CREATE_RETURN_FALSE();
			}
#ifdef SHOUT_DEBUG
			php_printf("Success\n");
#endif
			MySG(num_persistent)++;
			MySG(num_links)++;
		} else {  //********************* The link is in our list of persistent connections
#ifdef SHOUT_DEBUG
			php_printf("FOUND!\n");
#endif
			if (Z_TYPE_P(le) != le_plink) {
				SHOUT_CREATE_RETURN_FALSE();
			}
			shout = (php_shout_conn *) le->ptr;
		}
		ZEND_REGISTER_RESOURCE(return_value, shout, le_plink);

	} else {	//********************** User chose NON-persistent link
#ifdef SHOUT_DEBUG
	php_printf("Creating Non-Persistent Object\n");
#endif

		zend_rsrc_list_entry *index_ptr, new_index_ptr;

		// try to find if we already have this link in our regular list
		if (zend_hash_find(&EG(regular_list), hashed_details, hashed_details_length+1, (void **) &index_ptr)==SUCCESS) {
			int type;
			long link;
			void *ptr;

			if (Z_TYPE_P(index_ptr) != le_index_ptr) {
				SHOUT_CREATE_RETURN_FALSE();
			}
			link = (long) index_ptr->ptr;
			ptr = zend_list_find(link, &type);   // check if the link is still there
			if (ptr && (type == le_link)) {
				zend_list_addref(link);
				Z_LVAL_P(return_value) = link;
				php_shout_set_default_link(link TSRMLS_CC);
				Z_TYPE_P(return_value) = IS_RESOURCE;
				efree(hashed_details);
				SHOUT_CREATE_CLEANUP();
				return;
			} else {
				zend_hash_del(&EG(regular_list), hashed_details, hashed_details_length+1);
			}
		}

		if (MySG(max_links) != -1 && MySG(num_links) >= MySG(max_links)) {
			php_error_docref(NULL TSRMLS_CC, E_WARNING, "Too many open links (%ld)", MySG(num_links));
			efree(hashed_details);
			SHOUT_CREATE_RETURN_FALSE();
		}
		shout = (php_shout_conn *) malloc(sizeof(php_shout_conn));
		shout->conn = shout_new();
		shout->inUse = 0;

		if (shout_set_host(shout->conn, host) != SHOUTERR_SUCCESS) {
			php_error_docref(NULL TSRMLS_CC, E_WARNING, "Error setting hostname to '%s': %s\n", host, shout_get_error(shout->conn));
		}
		if (shout_set_port(shout->conn, port) != SHOUTERR_SUCCESS) {
			php_error_docref(NULL TSRMLS_CC, E_WARNING, "Error setting port to '%i': %s\n", port, shout_get_error(shout->conn));
		}
		if (shout_set_mount(shout->conn, mount) != SHOUTERR_SUCCESS) {
			php_error_docref(NULL TSRMLS_CC, E_WARNING, "Error setting mount to '%s': %s\n", mount, shout_get_error(shout->conn));
		}
		if (shout_set_user(shout->conn, user) != SHOUTERR_SUCCESS) {
			php_error_docref(NULL TSRMLS_CC, E_WARNING, "Error setting user to '%s': %s\n", user, shout_get_error(shout->conn));
		}
		if (shout_set_password(shout->conn, password) != SHOUTERR_SUCCESS) {
			php_error_docref(NULL TSRMLS_CC, E_WARNING, "Error setting password to '%s': %s\n", password, shout_get_error(shout->conn));
		}
		if (shout_set_format(shout->conn, format) != SHOUTERR_SUCCESS) {
			php_error_docref(NULL TSRMLS_CC, E_WARNING, "Error setting format to '%i': %s\n", format, shout_get_error(shout->conn));
		}
		if (shout_set_protocol(shout->conn, protocol) != SHOUTERR_SUCCESS) {
			php_error_docref(NULL TSRMLS_CC, E_WARNING, "Error setting protocol to '%i': %s\n", protocol, shout_get_error(shout->conn));
		}

		// add it to the list
		ZEND_REGISTER_RESOURCE(return_value, shout, le_link);
	
		// add it to the hash
		new_index_ptr.ptr = (void *) Z_LVAL_P(return_value);
		Z_TYPE(new_index_ptr) = le_index_ptr;
		if (zend_hash_update(&EG(regular_list), hashed_details, hashed_details_length+1,(void *) &new_index_ptr, sizeof(zend_rsrc_list_entry), NULL)==FAILURE) {
			shout_free(shout->conn);
			free(shout);
			efree(hashed_details);
			SHOUT_CREATE_RETURN_FALSE();
		}
		MySG(num_links)++;
	}
	efree(hashed_details);
	php_shout_set_default_link(Z_LVAL_P(return_value) TSRMLS_CC);
	SHOUT_CREATE_CLEANUP();
}
/* }}} */

/* {{{ php_shout_get_default_link
 */
static int php_shout_get_default_link(INTERNAL_FUNCTION_PARAMETERS) {
	if (MySG(default_link)==-1) { /* no link opened yet, implicitly open one */
		ht = 0;
		php_shout_create(INTERNAL_FUNCTION_PARAM_PASSTHRU, 0);
	}
	return MySG(default_link);
}
/* }}} */

/* {{{ php_shout_connect
 */
static void php_shout_connect(INTERNAL_FUNCTION_PARAMETERS) {
	zval *shout_link = NULL;
	int id = -1;
	php_shout_conn *shout;

	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "|r", &shout_link) == FAILURE) {
		return;
	}
	if (ZEND_NUM_ARGS() == 0) {
		id = php_shout_get_default_link(INTERNAL_FUNCTION_PARAM_PASSTHRU);
	}

	ZEND_FETCH_RESOURCE2(shout, php_shout_conn *, &shout_link, id, "Shout Connection", le_link, le_plink);

#ifdef SHOUT_DEBUG
	php_printf("In php_shout_connect, attempting shout_open()...\n");
#endif
	int retval = shout_open(shout->conn);
#ifdef SHOUT_DEBUG
	php_printf("retval=%i\n", retval);
#endif
	if (retval != SHOUTERR_SUCCESS) {
		php_error_docref(NULL TSRMLS_CC, E_WARNING, "Error Connecting: %s", shout_get_error(shout->conn));
	}

	RETURN_LONG(retval);
}
/* }}} */

void php_shout_get_string_param(INTERNAL_FUNCTION_PARAMETERS, char *name) {
	zval *shout_link = NULL;
	int id = -1;
	const char *value = NULL;
	php_shout_conn *shout;

	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "|r", &shout_link) == FAILURE) {
		return;
	}
	if (ZEND_NUM_ARGS() == 0) {
		id = php_shout_get_default_link(INTERNAL_FUNCTION_PARAM_PASSTHRU);
	}

	ZEND_FETCH_RESOURCE2(shout, php_shout_conn *, &shout_link, id, "Shout Connection", le_link, le_plink);

	if (name == "host")             value = shout_get_host(shout->conn);
	else if (name == "password")    value = shout_get_password(shout->conn);
	else if (name == "mount")       value = shout_get_mount(shout->conn);
	else if (name == "name")        value = shout_get_name(shout->conn);
	else if (name == "url")         value = shout_get_url(shout->conn);
	else if (name == "genre")       value = shout_get_genre(shout->conn);
	else if (name == "user")        value = shout_get_user(shout->conn);
	else if (name == "agent")       value = shout_get_agent(shout->conn);
	else if (name == "description") value = shout_get_description(shout->conn);
	else if (name == "error")       value = shout_get_error(shout->conn);
	else {
		php_error_docref(NULL TSRMLS_CC, E_WARNING, "Unknown string property '%s'", name);
	}
#ifdef SHOUT_DEBUG
	php_printf("In get_string_param(), returning '%s'='%s'\n", name, SAFE_STRING(value));
#endif

	RETURN_STRING(SAFE_STRING((char *)value), 1);
}

void php_shout_get_int_param(INTERNAL_FUNCTION_PARAMETERS, char *name) {
	zval *shout_link = NULL;
	int id = -1;
	int value = 0;
	php_shout_conn *shout;

	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "|r", &shout_link) == FAILURE) {
		return;
	}
	if (ZEND_NUM_ARGS() == 0) {
		id = php_shout_get_default_link(INTERNAL_FUNCTION_PARAM_PASSTHRU);
	}

	ZEND_FETCH_RESOURCE2(shout, php_shout_conn *, &shout_link, id, "Shout Connection", le_link, le_plink);

	if (name == "connected")        value = shout_get_connected(shout->conn);
	else if (name == "port")        value = shout_get_port(shout->conn);
	else if (name == "public")      value = shout_get_public(shout->conn);
	else if (name == "format")      value = shout_get_format(shout->conn);
	else if (name == "protocol")    value = shout_get_protocol(shout->conn);
	else if (name == "nonblocking") value = shout_get_nonblocking(shout->conn);
	else if (name == "errno")       value = shout_get_errno(shout->conn);

#ifdef SHOUT_DEBUG
	php_printf("In get_int_param(), returning '%s'='%ld'\n", name, value);
#endif

	RETURN_LONG(value);
}
void php_shout_set_string_param(INTERNAL_FUNCTION_PARAMETERS, char *name) {
	zval *shout_link;
	char *setVal;
	int setValLen;
	int id = -1;
	int retval = 0;
	php_shout_conn *shout;

	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "rs", &shout_link, &setVal, &setValLen) == FAILURE) {
		if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "s", &setVal, &setValLen) == FAILURE) {
			return;
		}
	}
	if (ZEND_NUM_ARGS() == 1) {
		id = php_shout_get_default_link(INTERNAL_FUNCTION_PARAM_PASSTHRU);
	}
	ZEND_FETCH_RESOURCE2(shout, php_shout_conn *, &shout_link, id, "Shout Connection", le_link, le_plink);

	if (name == "host")             retval = shout_set_host(shout->conn, setVal);
	else if (name == "password")    retval = shout_set_password(shout->conn, setVal);
	else if (name == "mount")       retval = shout_set_mount(shout->conn, setVal);
	else if (name == "name")        retval = shout_set_name(shout->conn, setVal);
	else if (name == "url")         retval = shout_set_url(shout->conn, setVal);
	else if (name == "genre")       retval = shout_set_genre(shout->conn, setVal);
	else if (name == "user")        retval = shout_set_user(shout->conn, setVal);
	else if (name == "agent")       retval = shout_set_agent(shout->conn, setVal);
	else if (name == "description") retval = shout_set_description(shout->conn, setVal);

#ifdef SHOUT_DEBUG
	php_printf("In set_string_param(), setting '%s'='%s'\n", name, SAFE_STRING(setVal));
#endif

	if (retval != SHOUTERR_SUCCESS) {
		php_error_docref(NULL TSRMLS_CC, E_WARNING, "Error setting parameter '%s': %s", name, shout_get_error(shout->conn));
	}

	RETURN_LONG(retval);
}

void php_shout_set_int_param(INTERNAL_FUNCTION_PARAMETERS, char *name) {
	zval *shout_link;
	int setVal;
	int id = -1;
	int retval = 0;
	php_shout_conn *shout;

	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "rl", &shout_link, &setVal) == FAILURE) {
		if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "l", &setVal) == FAILURE) {
			return;
		}
	}

	ZEND_FETCH_RESOURCE2(shout, php_shout_conn *, &shout_link, id, "Shout Connection", le_link, le_plink);

	if (name == "port")             retval = shout_set_port(shout->conn, setVal);
	else if (name == "public")      retval = shout_set_public(shout->conn, setVal);
	else if (name == "format")      retval = shout_set_format(shout->conn, setVal);
	else if (name == "protocol")    retval = shout_set_protocol(shout->conn, setVal);
	else if (name == "nonblocking") retval = shout_set_nonblocking(shout->conn, setVal);

	if (retval != SHOUTERR_SUCCESS) {
		php_error_docref(NULL TSRMLS_CC, E_WARNING, "Error setting parameter '%s': %s", name, shout_get_error(shout->conn));
	}

#ifdef SHOUT_DEBUG
	php_printf("In set_int_param(), setting '%s'='%ld'\n", name, setVal);
#endif

	RETURN_LONG(retval);
}

/* {{{ shout_get_all_persistent
 */
PHP_FUNCTION(shout_get_all_persistent) {
	zval *data;
	zend_rsrc_list_entry *le;
	HashPosition pointer;
	//php_shout_conn *shout;
	
	array_init(return_value);

#ifdef SHOUT_DEBUG
	php_printf("shout_get_all_persistent(), finding Persistent links... ");
#endif

	// Get all Persistent Resources
	for(zend_hash_internal_pointer_reset_ex(&EG(persistent_list), &pointer);
			zend_hash_get_current_data_ex(&EG(persistent_list), (void**) &le, &pointer) == SUCCESS;
			zend_hash_move_forward_ex(&EG(persistent_list), &pointer)) {
			
		if (le->type != le_plink) continue; // isn't a Shout resource
		char *key, *token, *hostname, *port, *mount, *URI;
		unsigned int keyType, key_len, URI_len;
		unsigned long index = 0;
		keyType = zend_hash_get_current_key_ex(&EG(persistent_list), &key, &key_len, &index, 0, &pointer);
		if (keyType == HASH_KEY_IS_STRING) {
			// Construct Array Key
			token = strtok(key, "_");
			if (strcmp(token, "shout") != 0) continue; // isn't a Shout resource
			token = strtok(NULL, "_");
			if (token == NULL) continue; // Didn't get a hostname
			hostname = token;
			token = strtok(NULL, "_");
			if (token == NULL) continue; // Didn't get a post
			port = token;
			token = strtok(NULL, "_");
			if (token == NULL) continue; // Didn't get a mount
			mount = token;
			URI_len = spprintf(&URI, 0, "%s:%i%s", hostname, atoi(port), mount);

#ifdef SHOUT_DEBUG
	php_printf("%s ", URI);
#endif

			// Instantiate the Resource and add it to the array
			ALLOC_INIT_ZVAL(data);
			ZEND_REGISTER_RESOURCE(data, le->ptr, le->type);
			add_assoc_zval_ex(return_value, URI, URI_len + 1, data);
		}
	}

#ifdef SHOUT_DEBUG
	php_printf("\n");
#endif
}
/* }}} */

PHP_FUNCTION(shout_create) {
	php_shout_create(INTERNAL_FUNCTION_PARAM_PASSTHRU, 0);
}

PHP_FUNCTION(shout_pcreate) {
	php_shout_create(INTERNAL_FUNCTION_PARAM_PASSTHRU, 1);
}

PHP_FUNCTION(shout_connect) {
	php_shout_connect(INTERNAL_FUNCTION_PARAM_PASSTHRU);
}

PHP_FUNCTION(shout_close) {
	zval *shout_link=NULL;
	int id = -1;
	php_shout_conn *shout;

	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "|r", &shout_link) == FAILURE) {
		return;
	}
	if (ZEND_NUM_ARGS() == 0) {
		id = MySG(default_link);
	}

	ZEND_FETCH_RESOURCE2(shout, php_shout_conn *, &shout_link, id, "Shout Connection", le_link, le_plink);

	if (id == -1) { /* explicit resource number */
		zend_list_delete(Z_RESVAL_P(shout_link));
	}

	if (id != -1 || (shout_link && Z_RESVAL_P(shout_link) == MySG(default_link))) {
		zend_list_delete(MySG(default_link));
		MySG(default_link) = -1;
	}

	RETURN_TRUE;
}

PHP_FUNCTION(shout_send) {
	zval *shout_link;
	unsigned char *buff;
	int buffLen;
	int id = -1;
	php_shout_conn *shout;

	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "rs", &shout_link, &buff, &buffLen) == FAILURE) {
		if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "s", &buff, &buffLen) == FAILURE) {
			return;
		}
	}
	if (ZEND_NUM_ARGS() == 1) {
		id = php_shout_get_default_link(INTERNAL_FUNCTION_PARAM_PASSTHRU);
	}
	ZEND_FETCH_RESOURCE2(shout, php_shout_conn *, &shout_link, id, "Shout Connection", le_link, le_plink);
	
	int retval = shout_send(shout->conn, buff, buffLen);
	if (retval != SHOUTERR_SUCCESS) {
		php_error_docref(NULL TSRMLS_CC, E_WARNING, "Error sending data: %s", shout_get_error(shout->conn));
	}
	RETURN_LONG(retval);
}

PHP_FUNCTION(shout_sync) {
	zval *shout_link;
	int id = -1;
	php_shout_conn *shout;

	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "|r", &shout_link) == FAILURE) {
		return;
	}
	if (ZEND_NUM_ARGS() == 0) {
		id = php_shout_get_default_link(INTERNAL_FUNCTION_PARAM_PASSTHRU);
	}

	ZEND_FETCH_RESOURCE2(shout, php_shout_conn *, &shout_link, id, "Shout Connection", le_link, le_plink);
	shout_sync(shout->conn);
	RETURN_TRUE;
}

// get_* functions

PHP_FUNCTION(shout_get_connected) {
	php_shout_get_int_param(INTERNAL_FUNCTION_PARAM_PASSTHRU, "connected");
}

PHP_FUNCTION(shout_get_errno) {
	php_shout_get_int_param(INTERNAL_FUNCTION_PARAM_PASSTHRU, "errno");
}

PHP_FUNCTION(shout_get_error) {
	php_shout_get_string_param(INTERNAL_FUNCTION_PARAM_PASSTHRU, "error");
}

PHP_FUNCTION(shout_get_host) {
	php_shout_get_string_param(INTERNAL_FUNCTION_PARAM_PASSTHRU, "host");
}

PHP_FUNCTION(shout_get_port) {
	php_shout_get_int_param(INTERNAL_FUNCTION_PARAM_PASSTHRU, "port");
}

PHP_FUNCTION(shout_get_password) {
	php_shout_get_string_param(INTERNAL_FUNCTION_PARAM_PASSTHRU, "password");
}

PHP_FUNCTION(shout_get_mount) {
	php_shout_get_string_param(INTERNAL_FUNCTION_PARAM_PASSTHRU, "mount");
}

PHP_FUNCTION(shout_get_name) {
	php_shout_get_string_param(INTERNAL_FUNCTION_PARAM_PASSTHRU, "name");
}

PHP_FUNCTION(shout_get_url) {
	php_shout_get_string_param(INTERNAL_FUNCTION_PARAM_PASSTHRU, "url");
}

PHP_FUNCTION(shout_get_genre) {
	php_shout_get_string_param(INTERNAL_FUNCTION_PARAM_PASSTHRU, "genre");
}

PHP_FUNCTION(shout_get_user) {
	php_shout_get_string_param(INTERNAL_FUNCTION_PARAM_PASSTHRU, "user");
}

PHP_FUNCTION(shout_get_agent) {
	php_shout_get_string_param(INTERNAL_FUNCTION_PARAM_PASSTHRU, "agent");
}

PHP_FUNCTION(shout_get_description) {
	php_shout_get_string_param(INTERNAL_FUNCTION_PARAM_PASSTHRU, "decription");
}

PHP_FUNCTION(shout_get_public) {
	php_shout_get_int_param(INTERNAL_FUNCTION_PARAM_PASSTHRU, "public");
}

PHP_FUNCTION(shout_get_format) {
	php_shout_get_int_param(INTERNAL_FUNCTION_PARAM_PASSTHRU, "format");
}

PHP_FUNCTION(shout_get_protocol) {
	php_shout_get_int_param(INTERNAL_FUNCTION_PARAM_PASSTHRU, "protocol");
}

PHP_FUNCTION(shout_get_nonblocking) {
	php_shout_get_int_param(INTERNAL_FUNCTION_PARAM_PASSTHRU, "nonblocking");
}

PHP_FUNCTION(shout_get_audio_info) {
	zval *shout_link;
	char *name;
	int nameLen;
	int id = -1;
	php_shout_conn *shout;

	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "rs", &shout_link, &name, &nameLen) == FAILURE) {
		if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "s", &name, &nameLen) == FAILURE) {
			return;
		}
	}
	if (ZEND_NUM_ARGS() == 1) {
		id = php_shout_get_default_link(INTERNAL_FUNCTION_PARAM_PASSTHRU);
	}
	ZEND_FETCH_RESOURCE2(shout, php_shout_conn *, &shout_link, id, "Shout Connection", le_link, le_plink);
	
	char *value = (char *)shout_get_audio_info(shout->conn, name);
	RETURN_STRING(value, 1);
}


// set_* functions

PHP_FUNCTION(shout_set_host) {
	php_shout_set_string_param(INTERNAL_FUNCTION_PARAM_PASSTHRU, "host");
}

PHP_FUNCTION(shout_set_port) {
	php_shout_set_int_param(INTERNAL_FUNCTION_PARAM_PASSTHRU, "port");
}

PHP_FUNCTION(shout_set_password) {
	php_shout_set_string_param(INTERNAL_FUNCTION_PARAM_PASSTHRU, "password");
}

PHP_FUNCTION(shout_set_mount) {
	php_shout_set_string_param(INTERNAL_FUNCTION_PARAM_PASSTHRU, "mount");
}

PHP_FUNCTION(shout_set_name) {
	php_shout_set_string_param(INTERNAL_FUNCTION_PARAM_PASSTHRU, "name");
}

PHP_FUNCTION(shout_set_url) {
	php_shout_set_string_param(INTERNAL_FUNCTION_PARAM_PASSTHRU, "url");
}

PHP_FUNCTION(shout_set_genre) {
	php_shout_set_string_param(INTERNAL_FUNCTION_PARAM_PASSTHRU, "genre");
}

PHP_FUNCTION(shout_set_user) {
	php_shout_set_string_param(INTERNAL_FUNCTION_PARAM_PASSTHRU, "user");
}

PHP_FUNCTION(shout_set_agent) {
	// Append our own info at the end of the agent string
	zval *shout_link;
	char *setVal;
	int setValLen;
	int id = -1;
	int retval;
	int major=0, minor=0, patch=0;
	php_shout_conn *shout;

	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "rs", &shout_link, &setVal, &setValLen) == FAILURE) {
		if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "s", &setVal, &setValLen) == FAILURE) {
			return;
		}
	}
	if (ZEND_NUM_ARGS() == 1) {
		id = php_shout_get_default_link(INTERNAL_FUNCTION_PARAM_PASSTHRU);
	}
	ZEND_FETCH_RESOURCE2(shout, php_shout_conn *, &shout_link, id, "Shout Connection", le_link, le_plink);

	shout_version(&major, &minor, &patch);
	char agent[1024];
	sprintf(agent, "%s (phpShout-%s) (libshout-%i.%i.%i)", setVal, PHP_SHOUT_VERSION, major, minor, patch);
//	agent[1023] = '\0';
	retval = shout_set_agent(shout->conn, agent);
	if (retval != SHOUTERR_SUCCESS) {
		php_error_docref(NULL TSRMLS_CC, E_WARNING, "Error setting parameter 'agent': %s", shout_get_error(shout->conn));
	}
	RETURN_LONG(retval);
}

PHP_FUNCTION(shout_set_description) {
	php_shout_set_string_param(INTERNAL_FUNCTION_PARAM_PASSTHRU, "description");
}

PHP_FUNCTION(shout_set_public) {
	php_shout_set_int_param(INTERNAL_FUNCTION_PARAM_PASSTHRU, "public");
}

PHP_FUNCTION(shout_set_format) {
	php_shout_set_int_param(INTERNAL_FUNCTION_PARAM_PASSTHRU, "format");
}

PHP_FUNCTION(shout_set_protocol) {
	php_shout_set_int_param(INTERNAL_FUNCTION_PARAM_PASSTHRU, "protocol");
}

PHP_FUNCTION(shout_set_nonblocking) {
	php_shout_set_int_param(INTERNAL_FUNCTION_PARAM_PASSTHRU, "nonblocking");
}

PHP_FUNCTION(shout_set_metadata) {
	zval *shout_link;
	char *name, *value;
	int nameLen, valueLen;
	int id = -1;
	php_shout_conn *shout;
	shout_metadata_t *mdata;

	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "rss", &shout_link, &name, &nameLen, &value, &valueLen) == FAILURE) {
		if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "ss", &name, &nameLen, &value, &valueLen) == FAILURE) {
			return;
		}
	}
	if (ZEND_NUM_ARGS() == 2) {
		id = php_shout_get_default_link(INTERNAL_FUNCTION_PARAM_PASSTHRU);
	}
	ZEND_FETCH_RESOURCE2(shout, php_shout_conn *, &shout_link, id, "Shout Connection", le_link, le_plink);

	mdata = shout_metadata_new();
	int retval = shout_metadata_add(mdata, name, value);
	if (retval != SHOUTERR_SUCCESS) {
		php_error_docref(NULL TSRMLS_CC, E_WARNING, "Error creating metadata object: %s", shout_get_error(shout->conn));
		RETURN_LONG(retval);
	}
	retval = shout_set_metadata(shout->conn, mdata);
	shout_metadata_free(mdata);
	if (retval != SHOUTERR_SUCCESS) {
		php_error_docref(NULL TSRMLS_CC, E_WARNING, "Error setting stream metadata '%s': %s", name, shout_get_error(shout->conn));
	}
	RETURN_LONG(retval);
}

PHP_FUNCTION(shout_set_audio_info) {
	zval *shout_link;
	char *name, *value;
	int nameLen, valueLen;
	int id = -1;
	php_shout_conn *shout;

	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "rss", &shout_link, &name, &nameLen, &value, &valueLen) == FAILURE) {
		if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "ss", &name, &nameLen, &value, &valueLen) == FAILURE) {
			return;
		}
	}
	if (ZEND_NUM_ARGS() == 2) {
		id = php_shout_get_default_link(INTERNAL_FUNCTION_PARAM_PASSTHRU);
	}
	ZEND_FETCH_RESOURCE2(shout, php_shout_conn *, &shout_link, id, "Shout Connection", le_link, le_plink);

#ifdef SHOUT_DEBUG
	php_printf("Setting audio_info: '%s'='%s'\n", name, value);
#endif
	int retval = shout_set_audio_info(shout->conn, name, value);
	if (retval != SHOUTERR_SUCCESS) {
		php_error_docref(NULL TSRMLS_CC, E_WARNING, "Error setting audio_info: %s", shout_get_error(shout->conn));
	}

	RETURN_LONG(retval);
}
