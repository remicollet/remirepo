/* vim: set expandtab tabstop=4 shiftwidth=4 softtabstop=4: */
/* 
 * php_shout.h
 *
 * Copyright (C) 2005-2007 Brandon Holbrook <brandon@theholbrooks.org>
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Library General Public
 *  License as published by the Free Software Foundation; either
 *  version 2 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Library General Public License for more details.
 *
 *  You should have received a copy of the GNU Library General Public
 *  License along with this library; if not, write to the Free
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * $Id: php_shout.h 108 2007-01-06 05:01:27Z holbrookbw $
 */

#ifndef PHP_SHOUT_H
#define PHP_SHOUT_H 1

#define PHP_SHOUT_VERSION "0.9.2"
#define PHP_SHOUT_EXTNAME "shout"

#define SHOUT_PORT 8000

extern zend_module_entry shout_module_entry;

PHP_MINIT_FUNCTION(shout);
PHP_MSHUTDOWN_FUNCTION(shout);
PHP_RINIT_FUNCTION(shout);
PHP_RSHUTDOWN_FUNCTION(shout);
PHP_MINFO_FUNCTION(shout);

PHP_FUNCTION(shout_get_all_persistent);

PHP_FUNCTION(shout_create);
PHP_FUNCTION(shout_pcreate);
PHP_FUNCTION(shout_connect);
PHP_FUNCTION(shout_open);	// Alias for shout_connect
PHP_FUNCTION(shout_close);
PHP_FUNCTION(shout_send);
PHP_FUNCTION(shout_sync);

PHP_FUNCTION(shout_get_connected);
PHP_FUNCTION(shout_get_errno);
PHP_FUNCTION(shout_get_error);

PHP_FUNCTION(shout_get_host);
PHP_FUNCTION(shout_get_port);
PHP_FUNCTION(shout_get_password);
PHP_FUNCTION(shout_get_mount);
PHP_FUNCTION(shout_get_name);
PHP_FUNCTION(shout_get_url);
PHP_FUNCTION(shout_get_genre);
PHP_FUNCTION(shout_get_user);
PHP_FUNCTION(shout_get_agent);
PHP_FUNCTION(shout_get_description);
PHP_FUNCTION(shout_get_audio_info);
PHP_FUNCTION(shout_get_public);
PHP_FUNCTION(shout_get_format);
PHP_FUNCTION(shout_get_protocol);
PHP_FUNCTION(shout_get_nonblocking);

PHP_FUNCTION(shout_get_audio_info);

PHP_FUNCTION(shout_set_host);
PHP_FUNCTION(shout_set_port);
PHP_FUNCTION(shout_set_password);
PHP_FUNCTION(shout_set_mount);
PHP_FUNCTION(shout_set_name);
PHP_FUNCTION(shout_set_url);
PHP_FUNCTION(shout_set_genre);
PHP_FUNCTION(shout_set_user);
PHP_FUNCTION(shout_set_agent);
PHP_FUNCTION(shout_set_description);
PHP_FUNCTION(shout_set_audio_info);
PHP_FUNCTION(shout_set_public);
PHP_FUNCTION(shout_set_format);
PHP_FUNCTION(shout_set_protocol);
PHP_FUNCTION(shout_set_nonblocking);

PHP_FUNCTION(shout_set_metadata);
PHP_FUNCTION(shout_set_audio_info);

ZEND_BEGIN_MODULE_GLOBALS(shout)
		long default_link;
		long num_links, num_persistent;
		long max_links, max_persistent;
		zend_bool allow_persistent;
		long default_port;
		long default_protocol;
		long default_format;
		char *default_host;
		char *default_mount;
		char *default_user;
		char *default_password;
		char *connect_error;
		long connect_errno;
		long connect_timeout;
ZEND_END_MODULE_GLOBALS(shout)

#ifdef ZTS
	#define MySG(v) TSRMG(shout_globals_id, zend_shout_globals *, v)
#else
	#define MySG(v) (shout_globals.v)
#endif

#define phpext_shout_ptr &shout_module_entry

#endif /* PHP_SHOUT_H */
