<?
/*
 * phpShout
 * example1.php
 * 
 * $Id: example1.php 81 2006-03-06 05:40:15Z holbrookbw $
 */
if (!function_exists('shout_create')) dl('shout.so');

// Create Shout object and get Connection ID
$id = shout_create('/phpShout', 'source', 'hackme', SHOUT_FORMAT_MP3);

// Set station details, must be done BEFORE calling shout_connect 
shout_set_name($id, "This is the name of my Radio Station!");
shout_set_agent($id, "This is my UserAgent");
shout_set_description($id, "This is the description of my very own PHP radio station");

// Open connection
if (shout_connect($id) != SHOUTERR_SUCCESS) die("Could not open connection\n");

// Open MP3 and set metadata
$file = '/path/to/mysong.mp3';
$fh = fopen($file, 'r');
shout_set_metadata($id, 'song', basename($file));

// Read MP3 data into buffer and send to server
$BUFF_SIZE = 4096;
while ($buff = fread($fh, $BUFF_SIZE)) {
  if ($buff === false) break;
  if (shout_send($id, $buff) != SHOUTERR_SUCCESS) {
    die("ERROR SENDING DATA\n");
  }
  // Wait for server to be ready for more data
  shout_sync($id);
}
// Song's over, close Shout connection and MP3 file 
shout_close($id);
fclose($fh);
?>
