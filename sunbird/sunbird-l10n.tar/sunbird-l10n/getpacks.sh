# Fetch and pack latest Subird langpacks

set -o pipefail
set -e

mkdir -p sunbird-l10n
cp "$0" sunbird-l10n
cd sunbird-l10n
lynx -dump http://ftp.mozilla.org/pub/mozilla.org/calendar/sunbird/nightly/latest-comm-central-sunbird-l10n/ |
	awk '/^  *[0-9][0-9]*\. .*xpi$/ {print $2}' |xargs wget -c
cd ..
tar cf sunbird-l10n.tar sunbird-l10n
